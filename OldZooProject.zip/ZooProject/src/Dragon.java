

			public class Dragon extends Animals { //inherited child class of animals

				public int numOfEggs;
				public int numOfDrakes;
				public double numOfLiveFood;
				public Dragon(String typeOfAnimal)
					// TODO Auto-generated constructor stub
				
				
					{
						super(typeOfAnimal); 
						numOfEggs = numOfDrakes;
					} //void method
					public void setnumOfEggs(int newValue)
					{
						numOfEggs = numOfDrakes;
				
					}
					{
						 methoddangerLevel(178); //if-else void method for accessing park's threat level
				}

				public static void methoddangerLevel(double points) {
				  if (points >= 200) {
					  System.out.println("Current zoo status:");
				     System.out.println("Park is under threat.");
				  }else if (points >= 100) {
					  System.out.println("Current zoo status:");
				     System.out.println("Park is at risk.");
				  }else {
					  System.out.println("Current zoo status:");
				     System.out.println("Park is stable."); 
				  }}
					public int getNumOfEggs() {
						return numOfEggs;
					}
					public void setNumOfEggs(int numOfEggs) {
						this.numOfEggs = numOfEggs;
					}
					public int getNumOfDrakes() {
						return numOfDrakes;
					}
					public int setNumOfDrakes(int numOfDrakes) {
						return numOfDrakes;
					}
	
}



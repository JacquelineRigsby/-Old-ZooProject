import java.io.FileReader;

public class Addition {

	public double add(double a, double b, double c)  //overloaded method to count units of food in main class
	{
	return (a+b+c);}
public double add(double a, double b, double c, double d) {
	return (a+b+c+d);
}
}

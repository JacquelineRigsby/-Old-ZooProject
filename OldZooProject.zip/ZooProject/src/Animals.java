import java.util.ArrayList;
import java.util.Arrays;

public class Animals {
	public int numOfAnimal;
	public static double unitsOfFood;
	String diet, enclosure;
	static String typeOfAnimal;
	String ChooseAnimalType;
	Boolean emergency;
	String Dragon = "Y";
	
	
	
	public Animals(String typeOfAnimal) { //constructor method
		this.typeOfAnimal = typeOfAnimal;
	
	}
	double sum1 = 492; //method to increase units of food
	public static double addunitsOfFood(double sum1)
	{
		sum1++;
		return sum1;
	
	}
	
	public Boolean getEmergency() {
		return emergency;
	}

	public void setEmergency(Boolean emergency) {
		this.emergency = emergency;

			
		}
		public double getUnitsOfFood() {
			return unitsOfFood;
		}

		public void setUnitsOfFood(double unitsOfFood) {
			this.unitsOfFood = unitsOfFood;
		}

		public int getNumOfAnimal() {
			return numOfAnimal;
		}
		public void setNumOfAnimal(int numOfAnimal) {
			this.numOfAnimal = numOfAnimal;
		}
		public String getDiet() {
			return diet;
		}
		public void setDiet(String diet) {
			this.diet = diet;
		}
		public String getEnclosure() {
			return enclosure;
		}
		public void setEnclosure(String enclosure) {
			this.enclosure = enclosure;
		}
		public String getTypeOfAnimal() {
			return typeOfAnimal;
		}
		public void setTypeOfAnimal(String typeOfAnimal) {
			this.typeOfAnimal = typeOfAnimal; }
}
		
		
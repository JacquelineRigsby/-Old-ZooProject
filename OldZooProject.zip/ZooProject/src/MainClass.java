
import java.util.ArrayList;
import java.util.Scanner;



public class MainClass {

	public static void main(String[] args) {
		
		
		Dragon AncientDragon = new Dragon("Ancient Dragon"); //invoking constructors
		{
		AncientDragon.setUnitsOfFood(48);
		AncientDragon.setnumOfEggs(0);
		AncientDragon.setNumOfDrakes(0);
		AncientDragon.setNumOfAnimal(1);
		AncientDragon.setDiet("Carnivore");
		AncientDragon.setEnclosure("Castle");
		AncientDragon.setTypeOfAnimal("Dragon");
		AncientDragon.setEmergency(false);
		}
		Animals Dakotaraptor = new Animals("Dromaeosaur"); 
		{
		Dakotaraptor.setUnitsOfFood(48);
		Dakotaraptor.setNumOfAnimal(5);
		Dakotaraptor.setDiet("Carnivore");
		Dakotaraptor.setEnclosure("Forest Terrace");
		Dakotaraptor.setEmergency(false);
		}
		Animals Utahraptor = new Animals("Dromaeosaur");
		{
		Utahraptor.setUnitsOfFood(46);
		Utahraptor.setNumOfAnimal(2);
		Utahraptor.setDiet("Carnivore");
		Utahraptor.setEnclosure("Forest Terrace 2");
		Utahraptor.setEmergency(false);
		}
		Animals Austroraptor = new Animals("Dromaeosaur");
		{
		Austroraptor.setUnitsOfFood(23);
		Austroraptor.setNumOfAnimal(5);
		Austroraptor.setDiet("Piscivore");
		Austroraptor.setEnclosure("Forest Brook");
		Austroraptor.setEmergency(false);
		}
		Animals TyrannosaurusRex = new Animals("Tyrannosaur");
		{
		TyrannosaurusRex.setUnitsOfFood(378);
		TyrannosaurusRex.setNumOfAnimal(1);
		TyrannosaurusRex.setDiet("Carnivore");
		TyrannosaurusRex.setEnclosure("Forest Thicket");
		TyrannosaurusRex.setEmergency(false);
		}
		Animals Shantungosaurus = new Animals("Hadrosaur");
		{
		Shantungosaurus.setUnitsOfFood(653);
		Shantungosaurus.setNumOfAnimal(8);
		Shantungosaurus.setDiet("Herbivore");
		Shantungosaurus.setEnclosure("Forest Thicket 2");
		Shantungosaurus.setEmergency(false);
		}
		Animals Tarbosaurus = new Animals("Tyrannosaur");
		{
		Tarbosaurus.setUnitsOfFood(154);
		Tarbosaurus.setNumOfAnimal(3);
		Tarbosaurus.setDiet("Carnivore");
		Tarbosaurus.setEnclosure("Swamp Jungle");
		Tarbosaurus.setEmergency(false);
		}
		Animals Maiasaura = new Animals("Hadrosaur");
		{
		Maiasaura.setUnitsOfFood(347);
		Maiasaura.setNumOfAnimal(13);
		Maiasaura.setDiet("Herbivore");
		Maiasaura.setEnclosure("Rolling Plain");
		Maiasaura.setEmergency(false);
		}
		Animals Diplodocus = new Animals("Sauropod");
		{
		Diplodocus.setUnitsOfFood(3458);
		Diplodocus.setNumOfAnimal(5);
		Diplodocus.setDiet("Herbivore");
		Diplodocus.setEnclosure("Rolling Plain");
		Diplodocus.setEmergency(false);
		}
		Animals Puertasaurus = new Animals("Sauropod");
		{
		Puertasaurus.setUnitsOfFood(1790);
		Puertasaurus.setNumOfAnimal(1);
		Puertasaurus.setDiet("Herbivore");
		Puertasaurus.setEnclosure("Rolling Plain");
		Puertasaurus.setTypeOfAnimal("Sauropod");
		Puertasaurus.setEmergency(false);
		}
		Animals Mosasaurus = new Animals("Mosasauridae");
		{
		Mosasaurus.setUnitsOfFood(23);
		Mosasaurus.setNumOfAnimal(3);
		Mosasaurus.setDiet("Piscivore");
		Mosasaurus.setEnclosure("Lagoon");
		Mosasaurus.setEmergency(false);
		}
		Animals Tylosaurus = new Animals("Mosasauridae");
		{
		Tylosaurus.setUnitsOfFood(123);
		Tylosaurus.setNumOfAnimal(4);
		Tylosaurus.setDiet("Piscivore");
		Tylosaurus.setEnclosure("Lagoon 2");
		Tylosaurus.setEmergency(false);
		}
		
		{
			System.out.println(" ");
				System.out.println("Zoo search categories include :");
				System.out.println("1. Carnivores");
				System.out.println("2. Herbivores");
				System.out.println("3. Piscivores");
				System.out.println("4. Total food stockpiled");
				System.out.println("5. List of all dinosaurs");
				System.out.println("6. List current amount of food supplied to each dinosaur type");
				System.out.println("7. Check dragon stats");
				System.out.println("What would you like to search for?");
			
		} { //Initial search question that asks the user for what type of dinosaur they are looking for
		  Scanner sc = new Scanner(System.in);
			 int input = sc.nextInt();
			 switch (input) { //Beginning of nested switch statement narrowing down the search for a specific dinosaur
			    case 1: 
			      System.out.println("Carnivores selected");
			      System.out.println("Carnivores include :");
			      System.out.println("A. Dakotaraptor, B. Utahraptor, C. Tyrannosaurus Rex, and D. Tarbosaurus.");
			      Scanner ca = new Scanner(System.in);
			      String input1 = ca.nextLine();	
			      switch (input1) { 
			      case "A": { //Second layer of the nested switch statement that you use to select a dinosaur within the selected type
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do //multiple do-while loops get multiple variables for each species
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Dakotaraptor.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Dakotaraptor.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Dakotaraptor.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Dakotaraptor.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      case "B":  {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Utahraptor.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); 
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Utahraptor.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Utahraptor.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Utahraptor.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break;
			      case "C":  {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(TyrannosaurusRex.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(TyrannosaurusRex.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(TyrannosaurusRex.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(TyrannosaurusRex.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      case "D": {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Tarbosaurus.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Tarbosaurus.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Tarbosaurus.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Tarbosaurus.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      default: 
			    	  System.out.println("Please pick a valid carnivore");
			    	  break; } 
			      break; 
			    case 2: {
			      System.out.println("Herbivores selected");
			      System.out.println("Herbivors include :");
			      System.out.println("A. Shantungosaurus, B. Maiasaura, C. Puertasaurus, D. Diplodocus.");
			      Scanner cb = new Scanner(System.in);
			      String input2 = cb.nextLine();	
			      switch (input2) { 
			      case "A": {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Shantungosaurus.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Shantungosaurus.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Shantungosaurus.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Shantungosaurus.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      case "B": {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Dakotaraptor.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Maiasaura.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Maiasaura.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Maiasaura.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break;  
			      case "C": {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Puertasaurus.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Puertasaurus.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Puertasaurus.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Puertasaurus.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      case "D": 
			      {System.out.println("Press any number to loop through information about the dinosaur.");
		    	  int stop = 2;
		    	  Scanner ab = new Scanner(System.in);
		    	  int dChoice = ab.nextInt();
		    	  dChoice = 0;
		    	  do
				    {
		    		  System.out.println("Current amount of food:");
		    		  System.out.println(Diplodocus.getUnitsOfFood()); }
			    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
			    	  		stop++;  }{
			      int stop = 2;
	    	      Scanner ab = new Scanner(System.in);
	    	      int dChoice = ab.nextInt();
	    	      do
			        {
	    	    	  System.out.println("Number of Species:");
	    	    	  System.out.println(Diplodocus.getNumOfAnimal()); }
	    	      	  while (dChoice == 2 && stop <= 1); 
	    	      	   stop++;  }{
	    	      	int stop = 2;
			    	Scanner ab = new Scanner(System.in);
			    	int dChoice = ab.nextInt();
			    	do
					{
			    	System.out.println("Current enclosure:");
			    	System.out.println(Diplodocus.getEnclosure()); }
			    	while (dChoice == 2 && stop <= 1); 
			    	 stop++;  }
	    	      	 {
			    	int stop = 2;
					Scanner ab = new Scanner(System.in);
					int dChoice = ab.nextInt();
					do
					{
					System.out.println("Emergency status:");
					System.out.println(Diplodocus.getEmergency()); }
					while (dChoice == 2 && stop <= 1); 
					stop++;  }
			    	  break; 
			      default: 
			    	  System.out.println("Please pick a valid harbivore");
			    	  break; } 
			      break; }
			    case 3: 
			      System.out.println("Piscivores selected");
			      System.out.println("Piscivores include :");
			      System.out.println("A. Austroraptor, B. Mosasaurus, C. Tylosaurus.");
			      Scanner cc = new Scanner(System.in);
			      String input3 = cc.nextLine();	
			      switch (input3) { 
			      case "A": {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Austroraptor.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Austroraptor.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Austroraptor.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Austroraptor.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      case "B": {System.out.println("Press any number to loop through information about the dinosaur.");
		    	  int stop = 2;
		    	  Scanner ab = new Scanner(System.in);
		    	  int dChoice = ab.nextInt();
		    	  dChoice = 0;
		    	  do
				    {
		    		  System.out.println("Current amount of food:");
		    		  System.out.println(Mosasaurus.getUnitsOfFood()); }
			    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
			    	  		stop++;  }{
			      int stop = 2;
	    	      Scanner ab = new Scanner(System.in);
	    	      int dChoice = ab.nextInt();
	    	      do
			        {
	    	    	  System.out.println("Number of Species:");
	    	    	  System.out.println(Mosasaurus.getNumOfAnimal()); }
	    	      	  while (dChoice == 2 && stop <= 1); 
	    	      	   stop++;  }{
	    	      	int stop = 2;
			    	Scanner ab = new Scanner(System.in);
			    	int dChoice = ab.nextInt();
			    	do
					{
			    	System.out.println("Current enclosure:");
			    	System.out.println(Mosasaurus.getEnclosure()); }
			    	while (dChoice == 2 && stop <= 1); 
			    	 stop++;  }
	    	      	 {
			    	int stop = 2;
					Scanner ab = new Scanner(System.in);
					int dChoice = ab.nextInt();
					do
					{
					System.out.println("Emergency status:");
					System.out.println(Mosasaurus.getEmergency()); }
					while (dChoice == 2 && stop <= 1); 
					stop++;  }
			    	  break;  
			      case "C": {
			    	  System.out.println("Press any number to loop through information about the dinosaur.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(Tylosaurus.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(Tylosaurus.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(Tylosaurus.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(Tylosaurus.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }
			    	  break; 
			      default: 
			    	  System.out.println("Please pick a valid piscivore");
			    	  break; } 
			      break; 
			      
			      
			      
			      //end of dinosaur types
			      
			      
			  
			    case 4:{ //Case 4 is checking the food stockpiled
			    	System.out.println("Type of foods are listed in the order: Carnivore, Herbivore, Piscivore.");
					int[][][] array3D = {
						{
							{12199, 12823, 11295} //3d array for food stockpiled
						}
					};
					for(int [][] array2D: array3D) { //nested for loop
						for(int[] array1D: array2D) {
							for(int item: array1D) {
					System.out.println(item + " units of food type stockpiled."); 
					 }}}
					break;}
			    
			    
			  //1D arrays of different types of dinosaurs
			    
			    
			    case 5:{ 
			    	ArrayList<String> Carnivores = new ArrayList<String>(4);
					Carnivores.add("Dakotaraptor");
					Carnivores.add("Utahraptor");
					Carnivores.add("Tyrannosaurus Rex");
					Carnivores.add("Tarbosaurus");
				
					ArrayList<String> Herbivores = new ArrayList<>(4);
					Herbivores.add("Shantungosaurus");
					Herbivores.add("Maiasaura");
					Herbivores.add("Puertasaurus");
					Herbivores.add("Diplodocus");
				
					ArrayList<String> Piscivores = new ArrayList<>(3);
					Piscivores.add("Austroraptor");
					Piscivores.add("Mosasaurus");
					Piscivores.add("Tylosaurus");
					System.out.println("Carnivores:");
					
					for (int i = 0; i < 4; i++) { //for loops listing each category of dinosaur
						System.out.println(Carnivores.get(i).toString());
					}{
						System.out.println(" ");
					System.out.println("Herbivores:");
					}
					for (int i = 0; i < 4; i++) { 
						System.out.println(Herbivores.get(i).toString());
					}{
						System.out.println(" ");
					System.out.println("Piscivores:");
					}
					for (int i = 0; i < 3; i++) { 
					System.out.println(Piscivores.get(i).toString());
					}
			    break;}
			    case 6: {
			    	Addition aa = new Addition(); //using overloaded method to count units of food for each type
			    	System.out.println("Carnivores:");
			    	double sum1 = aa.add(Dakotaraptor.getUnitsOfFood(), Utahraptor.getUnitsOfFood(), TyrannosaurusRex.getUnitsOfFood() + Tarbosaurus.getUnitsOfFood());
					System.out.println(sum1);
					System.out.println("Herbivores:");
			    	double sum2 = aa.add(Puertasaurus.getUnitsOfFood(), Maiasaura.getUnitsOfFood(), Shantungosaurus.getUnitsOfFood() + Diplodocus.getUnitsOfFood());
					System.out.println(sum2);
			    	System.out.println("Piscivores:");
			    	double sum3 = aa.add(Austroraptor.getUnitsOfFood(), Mosasaurus.getUnitsOfFood(), Tylosaurus.getUnitsOfFood());
					System.out.println(sum3); 
					System.out.println("You have carnivore food would you like to add it? Y/N");
							Animals.addunitsOfFood(sum1);
							Scanner pa = new Scanner(System.in);
							String plus = pa.nextLine(); {
								
								switch(plus) { //switch statement for adding to carnivore food
								case "Y": { 
								System.out.println("Carnivore food is now " + sum1); 
								break;}
							    default:{
								System.out.println("No change to carnivore food"); 
								break;}}
								
							break;}
						
			    } //Case 7 for checking dragon subclass stats
			    case 7: {{
			    	  System.out.println("Press any number to loop through information about the dragon.");
			    	  int stop = 2;
			    	  Scanner ab = new Scanner(System.in);
			    	  int dChoice = ab.nextInt();
			    	  dChoice = 0;
			    	  do
					    {
			    		  System.out.println("Current amount of food:");
			    		  System.out.println(AncientDragon.getUnitsOfFood()); }
				    	  while (dChoice == 1 && stop <= 1); //do-while loop to check the selected dinosaur's food level
				    	  		stop++;  }{
				      int stop = 2;
		    	      Scanner ab = new Scanner(System.in);
		    	      int dChoice = ab.nextInt();
		    	      do
				        {
		    	    	  System.out.println("Number of Species:");
		    	    	  System.out.println(AncientDragon.getNumOfAnimal()); }
		    	      	  while (dChoice == 2 && stop <= 1); 
		    	      	   stop++;  }{
		    	      	int stop = 2;
				    	Scanner ab = new Scanner(System.in);
				    	int dChoice = ab.nextInt();
				    	do
						{
				    	System.out.println("Current enclosure:");
				    	System.out.println(AncientDragon.getEnclosure()); }
				    	while (dChoice == 2 && stop <= 1); 
				    	 stop++;  }
		    	      	 {
				    	int stop = 2;
						Scanner ab = new Scanner(System.in);
						int dChoice = ab.nextInt();
						do
						{
						System.out.println("Emergency status:");
						System.out.println(AncientDragon.getEmergency()); }
						while (dChoice == 2 && stop <= 1); 
						stop++;  }{
		    	      	int stop = 2;
			    	      Scanner ab = new Scanner(System.in);
			    	      int dChoice = ab.nextInt();
			    	      do
					        {
			    	    	  System.out.println("Number of eggs:");
			    	    	  System.out.println(AncientDragon.getNumOfDrakes()); }
			    	      	  while (dChoice == 2 && stop <= 1); 
			    	      	   stop++;  }
			    	 
			    	
			    	break;} 
			    default: { //Validation for nested switch statement
			      System.out.println("Invalid selection, please select a number 1 - 7.");
			    }
			    
	
		}}}}